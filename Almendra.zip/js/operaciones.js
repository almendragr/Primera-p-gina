
function ejercicio_1 (){
    
for (var n = 0; n < 10; n++)
if (n % 2 != 0)
{
console.log(n, "Es par")
} 
else{
console.log(n, "Es impar")
}
}


function ejercicio_2 (){

var num1 = 5;
var num2 = 8;
suma = num1 + num2;

console.log("La suma total es: " +suma)
}